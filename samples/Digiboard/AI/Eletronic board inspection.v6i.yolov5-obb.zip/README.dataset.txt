# Eletronic board inspection > 2023-04-17 12:37am
https://universe.roboflow.com/dayan-santos-mweeo/eletronic-board-inspection

Provided by a Roboflow user
License: CC BY 4.0

